/* eslint-disable prettier/prettier */
import { Injectable } from '@nestjs/common';

import { databaseConfig } from './db.config';

@Injectable()
export class SelectService {


  async getAllUsers(): Promise<any[]> {
    try {
      await databaseConfig.connect();
    //   const result = await databaseConfig.query('SELECT * FROM student');
     // return result.recordset;
     const request = databaseConfig.request();
     const query = `SELECT * FROM student WHERE id = 4 AND name= 'snehi'`;
     const result = await request.query(query);
     return result.recordset;
    } catch (err) {
      console.error(err);
    } finally {
      await databaseConfig.close();
    }
  }
    /************SELECT QUERY********************/
    async GetData(table:string,col:string[]) {
      try {
        await databaseConfig.connect();
        const result = await databaseConfig.query(`SELECT ${col} FROM ${table}`);
        // console.log(result);
        return result.recordset;
  
       
          // this.insertData();
      } catch (err) {
        console.error(err);
      } finally {
        await databaseConfig.close();
      }
    }

  //     /************SELECT WEHERE********************/
  //   async getRowsByCondition(columns: string[], table: string,condition: string){
  //   try {
  //     await databaseConfig.connect();
  //       const selectedColumns = columns.join(',');
  //       const query = `SELECT ${selectedColumns} FROM ${table} WHERE ${condition}`;
  //       const result = await databaseConfig.query(query);
  //       return result.recordset;   

  //   } catch (err) {
  //     console.error(err);
  //   } finally {
  //     await databaseConfig.close();
  // }


  
}


       
