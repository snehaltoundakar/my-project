/* eslint-disable prettier/prettier */

import { ConnectionPool } from 'mssql';

export const databaseConfig: ConnectionPool = new ConnectionPool({
  user: 'sa',
  password: 'snehal',
  server: 'localhost',
  database: 'test',
  options: {
    encrypt: true,
    enableArithAbort: true,
    trustServerCertificate:true,
  },
});

