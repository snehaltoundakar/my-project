/* eslint-disable prettier/prettier */
import { Body, Controller, Get, Post } from '@nestjs/common';
import { AppService } from './app.service';
import { SelectService } from './select.service';



@Controller()
export class AppController {
  constructor(private readonly appService: AppService ,
  private readonly selectService: SelectService ){}


  @Get()
  async getAllUsers(): Promise<any[]> {
    return this.selectService.getAllUsers();
  }

  @Post('/insert')
  insertData(@Body() data){
  return this.appService.insertData(data);
}

  @Post('/select')
  getData(@Body() data){
    return this.appService.selectAll(data);
  }

  @Post('/Studentid')
  insertStud(@Body() data){
    return this.appService.studentData(data);
  }
}