import { Body, Controller, Get, Post } from '@nestjs/common';
import { FrameService } from './frame.service (1)';

@Controller()
export class AppController {
  constructor(private readonly frameService: FrameService) {}

  @Get()
  getHello(): string {
    return this.frameService.getHello();
  }

  /*******Multiple insert Data********/
  @Post('/multiple')
  async MultipleInsertData(
    @Body() data: { [key: string]: any }[],
  ): Promise<any> {
    const tableData = data.map((item) => ({
      tableName: item.tableName,
      data: item.data,
    }));
    const result = await this.frameService.multipleInsertData(tableData);
    return result;
  }

  /*******Multiple rows********/
  @Post('/multipleTableRows')
  async insertTableRowsData(
    @Body() data: { tables: Record<string, any>[] },
  ): Promise<any> {
    console.log('insert Queries');
    const result = await this.frameService.multipleTableRowsData(data.tables);
    return result;
  }

  // /*******UPDATE********/
  // @Post('/update')
  // async updateData(
  //   @Body() data: { [key: string]: any; condition: string }[],
  // ): Promise<any> {
  //   const tableData = data.map((item) => ({
  //     tableName: item.tableName,
  //     data: item.data,
  //     condition: item.condition,
  //   }));
  //   const result = await this.appService.updateData(tableData);
  //   return result;
  // }

  // /**********DELETE*********/
  // @Post('/delete')
  // async deleteData(
  //   @Body() data: { [key: string]: any; condition: string }[],
  // ): Promise<any> {
  //   const tableData = data.map((item) => ({
  //     tableName: item.tableName,
  //     condition: item.condition,
  //   }));
  //   const result = await this.appService.deleteData(tableData);
  //   return result;
  // }
}
