/* eslint-disable prettier/prettier */
import * as sql from 'mssql';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { databaseConfig} from './db.config';



export async function connectToDatabase() {
  const config = {
    user: 'sa',
    password: 'snehal',
    server: 'localhost',
    database: 'test',
    options: {
      encrypt: true,
      trustServerCertificate: true,
    },
  };

  

//const transaction = new sql.Transaction()

 


//transaction.begin((_err: any) => {
    // ... error checks

    // const request = new sql.Request(transaction)
    // request.query('insert into mytable (mycolumn) values (12345)', (err, result) => {
    //     // ... error checks

    //     transaction.commit(err => {
    //         // ... error checks

    //         console.log("Transaction committed.")
    //     })
    // })
//})
  const pool = await new sql.ConnectionPool(config).connect();
  return pool;
  }
