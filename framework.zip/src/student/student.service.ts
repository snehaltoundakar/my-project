/* eslint-disable prefer-const */
/* eslint-disable prettier/prettier */
import { Injectable } from '@nestjs/common';
import { AppService} from '../app.service';

@Injectable()
export class StudentService {
    constructor(private appservice : AppService){}
    async insert(data){
        let student_data = new Object();
        student_data['first_name'] = data.firstname;
        student_data['lastname'] = data.lastname;
        student_data['age'] = data.age;
        student_data['name'] = 'stud';
        let stud_result = await this.appservice.insertData('stud');

        let marks = new Object()
        marks['english'] = data.marks.english;
        marks['hindi'] = data.marks.hindi;
        marks['maths'] = data.marks.maths;
        marks['total'] = (data.marks.english + data.marks.hindi + data.marks.maths);
        marks['status'] = Number((data.marks.english + data.marks.hindi + data.marks.maths)) > 70 ? 'A' : 'B';
        marks['sid'] = stud_result.id;
        marks['name'] = 'marks'

        marks = await this.appservice.insertData('marks');
    
    }
}
