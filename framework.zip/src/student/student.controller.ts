/* eslint-disable prettier/prettier */
import { Body, Controller, Post } from '@nestjs/common';
import { StudentService } from './student.service';

@Controller('student')
export class StudentController {
  constructor(private readonly studentService: StudentService) {}

  @Post()
  async stud_insert(@Body() data){
    return await this.studentService.insert(data);
  }
}
