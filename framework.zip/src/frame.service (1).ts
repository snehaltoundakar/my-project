/* eslint-disable prettier/prettier */
import { Injectable } from '@nestjs/common';
import { databaseConfig } from './db.config';

@Injectable()
export class FrameService {
  getHello(): string {
    return 'Hello World!';
  }

  /******Execute Query*************/
  async executeQuery(query: string, parameters?: any): Promise<any> {
    try {
      await databaseConfig.connect();
      const request = databaseConfig.request();
      if (parameters) {
        for (const [key, value] of Object.entries(parameters)) {
          request.input(key, value);
        }
      }
      const result = await request.query(query);
      return result.recordset;
    } catch (error) {
      console.log(error);
      throw error;
    } finally {
      databaseConfig.close();
    }
  }


  /********MULTIPLE DATA INSERT **********************/
  async multipleInsertData(tableData: { tableName: string; data: any }[]): Promise<any> {
    const queries = [];
    const parameters = {};
   
    for (const { tableName, data } of tableData){
  
      console.log(data);
      const dataset = await this.createObjectInsert(tableName,data);
      // console.log("dataset =",dataset);
      // console.log("dataset COLUMN =",dataset.keys);
      // console.log("dataset VALUE =",dataset.values);

      const placeholders = dataset.values.map((value, index) => `@${dataset.tableName}_${dataset.keys[index]}`);
      console.log("placeholders =",placeholders);
      const query = `INSERT INTO ${dataset.tableName} (${dataset.keys.join(', ')}) VALUES (${placeholders.join(', ')})`;
      queries.push(query);
      console.log(query);
     // console.log("Values Length=",dataset.values.length);
      for (let i = 0; i < dataset.values.length; i++) {
        parameters[`${dataset.tableName}_${dataset.keys[i]}`] =dataset.values[i];
        //console.log(parameters[`${dataset.tableName}_${dataset.keys[i]}`] =dataset.values[i]);
      }
    }

    const result = await this.executeQuery(queries.join(';'), parameters);
    return result;
  }




  //----------------------------- Create a Object For Insert Data ---------------------------//
  async createObjectInsert(tableName,data){

       const queries = [];
      //  const parameters = {};

        const returnObj:any = {};
        const fieldArray = [];
        const valueArray = [];
        const datatype = [];

        
        returnObj['tableName'] = tableName;
        console.log(tableName);
        const query = `select column_name,data_type from information_schema.columns where table_name ='${tableName}';`
        queries.push(query);
       // console.log(query);
      
        const result:any = await this.executeQuery(queries.join(';'), []);
        for(const item of result){
          datatype.push(JSON.parse(JSON.stringify(item)));
        }
        console.log(datatype);

        // console.log("Data :",data)
        // for (const property in data) {
        //   console.log(`${property}: ${data[property]}`);
        // }

        Object.keys(data).forEach(ele=>{
            if(data[ele] != '' && data[ele] != null && data[ele] != undefined){

              const filterObj = datatype.filter(eles=> eles.column_name == ele);
                console.log(filterObj);
                if(filterObj.length != 0){
                  if(filterObj[0].data_type == 'varchar' && typeof data[ele]=="string"){
                    fieldArray.push(ele);
                    valueArray.push(data[ele]);                     
                    //console.log(typeof data[ele], "accepeted val=",data[ele]); 
                  }
                 else if(filterObj[0].data_type == 'int' ||filterObj[0].data_type == 'numeric' || filterObj[0].data_type == 'nchar'  && typeof data[ele]=="number"){
                  fieldArray.push(ele);
                    valueArray.push(data[ele]);                     
                    console.log(typeof data[ele], "accepeted val=",data[ele]); 
                 }
                 else if(filterObj[0].data_type == 'bit' && typeof data[ele]=="boolean"){
                  fieldArray.push(ele);
                    valueArray.push(data[ele]);                     
                    console.log(typeof data[ele], "accepeted val=",data[ele]); 
                 }
                 else if(filterObj[0].data_type == 'date'){
                  fieldArray.push(ele);
                    valueArray.push(data[ele]);                     
                 }
                 else if(filterObj[0].data_type == 'int' && typeof data[ele]=="number"){
                  fieldArray.push(ele);
                    valueArray.push(data[ele]);                     
                    console.log(typeof data[ele], "accepeted val=",data[ele]); 
                 }
                }
                
            }
        })
       

        returnObj['keys'] = fieldArray;
        returnObj['values'] = valueArray;
        //console.log("keys :",fieldArray,"\nValues :",valueArray);
        //console.log("columns=",fieldArray," \nvalues=",valueArray,"datatype=",datatype );

        return returnObj;
  }
 

  

  /********MULTIPLE table and rows INSERT **********************/
    async multipleTableRowsData(tables: Record<string, any>[]){
      const queries = [];
      const parameters = {};

      for (const table of tables) {
        const { name, data } = table;
        const columns = Object.keys(data[0]);
        const rows = data.map(obj => Object.values(obj));

        console.log("cols=",columns,"\n Val=",rows)
    
        const placeholders = rows.map(row => `(${row.map(val => `'${val}'`).join(', ')})`).join(', ');
        const query = `INSERT INTO ${name} (${columns.join(', ')}) VALUES ${placeholders};`;
        queries.push(query);
        console.log(query);
        // for (let i = 0; i < rows.length; i++) {
        //   parameters[`${name}_${columns[i]}`] = rows[i];
        // }
      }
    
         const result = await this.executeQuery(queries.join(';'), parameters);
      return result;
    
    }
}
